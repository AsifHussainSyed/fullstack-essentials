class Restaurant{
	menu: string[]

	constructor(menu: string[]){
		this.menu = menu;
	}

	list(){
		console.log(this.menu);
	}
}

var restaurant = new Restaurant(["item1", "item2", "item3"]);

restaurant.list();
