class Automobile{
	protected fuelType: String = "petrol";
	protected price: number;

	getFuelType(){
		return this.fuelType;
	}

	getPrice(){
		return this.price;
	}

	printInfo(){
		console.log("I am an automobile");
	}
}

class Car extends Automobile {
	
	constructor(price: number) {
		super();
		this.price = price;
	}

	printInfo(){
		super.printInfo();
		console.log(super.getFuelType() + " fuel is $" + this.price)
	}
}

var car = new Car(10);
car.printInfo();