var Restaurant = /** @class */ (function () {
    function Restaurant(menu) {
        this.menu = menu;
    }
    Restaurant.prototype.list = function () {
        console.log(this.menu);
    };
    return Restaurant;
}());
var restaurant = new Restaurant(["item1", "item2", "item3"]);
restaurant.list();
