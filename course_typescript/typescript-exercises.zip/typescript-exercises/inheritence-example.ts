class Human{
	protected name: string;

	constructor(name: string) {
		this.name = name;
	}

	getName(){
		return this.name;
	}
}

class Employee extends Human {
	protected department: string;

	constructor(name: string, department: string) {
		super(name);
		this.department = department;
	}

	getInfo(){
		console.log("Employee " + super.getName() + " at department " + this.department);
	}
}

var emp = new Employee("Don", "Engineering");

emp.getInfo();